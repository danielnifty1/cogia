<aside>
    <div id="sidebar" class="nav-collapse">
    	<style type="text/css">
    		i{
    			color: orange !important;
    		}
    	</style>
        <!-- sidebar menu start-->
        <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
                 <h6 style="padding: 9px 9px; background-color: #2a3f54; color: white; font-weight: bold;">NAVIGATION </h6> 
                <li>
                    <a class="active">
                        <i class="fa fa-dashboard"></i>
                        <span>DASHBOARD</span>
                    </a>
                </li>
                 <h6 style="padding: 9px 9px; background-color: #2a3f54; color: white; font-weight: bold;">Member Activities </h6> 

                
                <li class="sub-menu">
                    <a href="members">
                        <i class="fa fa-users"></i>
                        <span>Members</span>
                    </a>
                  <!--   <ul class="sub">
						<li><a href="typography.html">Typography</a></li>
						<li><a href="glyphicon.html">glyphicon</a></li>
                        <li><a href="grids.html">Grids</a></li>
                    </ul> -->
                </li>
              
                <li class="sub-menu">
                    <a href="view_test">
                        <i class="fa fa-eye"></i>
                        <span>Testimony</span>
                    </a>
                   
                </li>
                
                  <li class="sub-menu">
                    <a href="approved_test">
                        <i class="fa fa-check"></i>
                        <span>Approved Tesimony</span>
                    </a>
                   
                </li>

                 <li class="sub-menu">
                    <a href="payments">
                        <i class="fa fa-money"></i>
                        <span>Payments</span>
                    </a>
                   
                </li>
                 <h6 style="padding: 9px 9px; background-color: #2a3f54; color: white; font-weight: bold;">ACTIVITY POSTS </h6> 

                <li class="sub-menu">
                    <a href="trending">
                        <i class="fa fa-plus"></i>
                        <span>Add Event</span>
                    </a>
                   
                </li>

                 <li class="sub-menu">
                    <a href="view_events">
                        <i class="fa fa-eye"></i>
                        <span>View Events</span>
                    </a>
                   
                </li>

                 <li class="sub-menu">
                    <a href="offerrings">
                        <i class="fa fa-moneys">$</i>
                        <span>Offerings</span>
                    </a>
                   
                </li>
                 <h6 style="padding: 9px 9px; background-color: #2a3f54; color: white; font-weight: bold;">PASTORS </h6> 

                <li class="sub-menu">
                    <a href="addpastor">
                        <i class="fa fa-plus"></i>
                        <span>Add Pastor </span>
                    </a>
                    
                </li>
                <li class="sub-menu">
                    <a href="viewpastors">
                        <i class=" fa fa-users"></i>
                        <span>Pastors</span>
                    </a>
                    
                </li>
                 <h6 style="padding: 9px 9px; background-color: #2a3f54; color: white; font-weight: bold;">INBOX </h6> 

                <li class="sub-menu">
                    <a href="inbox">
                        <i class=" fa fa-envelope"></i>
                        <span>MESSAGES</span>
                    </a>
                    
                </li>
                 <h6 style="padding: 9px 9px; background-color: #2a3f54; color: white; font-weight: bold;">LOGOUT </h6> 

              
                <li>
                    <a href="logout">
                        <i class="fa fa-signing" style="color: orange"></i>
                        <span>Logout</span>
                    </a>
                </li>
            </ul>            </div>
        <!-- sidebar menu end-->
    </div>
</aside>